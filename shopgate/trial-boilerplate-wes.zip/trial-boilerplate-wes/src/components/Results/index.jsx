import React, { Component } from 'react';
import { css } from 'glamor';
import ResultCard from '../ResultCard';

const Results = ({ items = []}) => {
  const results = css({
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'stretch',
      flexWrap: 'wrap',
      marginTop: '1rem',
  })
  return (
    <div>
      <h2>5 Day Forecast</h2>
      <div className={results}>
        {items.map((item, index) => {
          const date = item.dt_txt.split(' ')[0]
          const weather = item.weather
          return (
            <ResultCard key={index} {...item} />
          )
        })}
      </div>
    </div>
  )
}

export default Results;
