import React, { Component } from 'react';
import { css } from 'glamor';
import { getWeather, getForecast } from '../../utils/weather';
import Results from '../Results';
import ErrorMessage from '../ErrorMessage';

class Form extends Component {
  constructor (props) {
    super(props)
    this.handleSubmit = this.handleSubmit.bind(this)
  }

  state = {
    city: '',
    forecast: [],
    errorMessage: false
  }

  handleSubmit = (e) => {
    e.preventDefault();
    Promise.resolve()
      getForecast(this.state.city)
      .then((result) => {
        const forecast5Day = result.data.list.slice(0,5)
        this.setState({
          forecast: forecast5Day,
          errorMessage: false
        })
      })
      .catch(error => {
        this.setState({
          forecast: [],
          errorMessage: true
        })
      })
  }

  render () {
    const form = css({
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'flex-end',
      marginBottom: '2rem',
      paddingBottom: '2rem',
      borderBottom: '1px solid #e1e2e1',

      '& label': {
        display: 'block',
        textAlign: 'left',
        marginBottom: '0.25rem'
      },

      '& input': {
        padding: '0.5rem'
      },

      '& button': {
        backgroundColor: '#D26C22',
        border: '0 none',
        color: 'white',
        padding: '0.5rem 1rem',
        fontSize: '1rem',
        cursor: 'pointer',

        '&:hover': {
          backgroundColor: '#9E511A'
        },

        '&:disabled': {
          cursor: 'not-allowed',
          backgroundColor: '#adadad'
        }
      }

    })
    const { city, forecast, errorMessage } = this.state
    return (
      <div>
        <form className={form} onSubmit={this.handleSubmit}>
          <div>
            <label htmlFor='city'>City</label>
            <input
              id='city'
              type='text'
              autoComplete='off'
              onChange={ e => this.setState({ city: e.target.value }) }
            />
          </div>
          <div>
            <button
              type='submit'
              disabled={!city}>
                Submit
            </button>
          </div>
        </form>
        {forecast.length > 0 && (
          <Results items={forecast} />
        )}
        {errorMessage && (
          <ErrorMessage message={errorMessage} />
        )}
      </div>
    )
  }
}

export default Form;
