import React from 'react';
import { css } from 'glamor';

const container = css({
  maxWidth: '500px',
  backgroundColor: 'red',
  borderRadius: '10px',
  color: 'white',
  fontWeight: 'bold',
  margin: '2rem auto',
  padding: '2rem',
  textAlign: 'center'
})

const ErrorMessage = () => (
  <div className={container}>
    <h4>Error, please try again</h4>
  </div>
)

export default ErrorMessage;
