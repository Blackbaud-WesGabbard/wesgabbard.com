import React from 'react';
import { css } from 'glamor';

const container = css({
  maxWidth: '1500px',
  margin: '2rem auto',
  padding: '1rem',
  textAlign: 'center',
})

const Container = ({ children }) => (
  <div className={container}>
    {children}
  </div>
)

export default Container;
