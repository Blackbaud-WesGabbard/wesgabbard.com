import { css } from 'glamor';

export default css({
  alignItems: 'center',
  display: 'flex',
  marginTop: '1rem',
  justifyContent: 'center',
  ' svg': {
    height: 36,
  },
});
