import React, { Component } from 'react';
import { css } from 'glamor';

const ResultCard = (item) => {
  const date = item.dt_txt.split(' ')[0]
  const weather = item.weather

  const result = css({
      padding: '1rem',
      border: '1px solid #e2e1e2',
      textAlign: 'left',
      margin: '1rem',
      width: '200px',
      boxShadow: '0px 2px 5px 0px rgba(0,0,0,0.75)',
  })
  return (
    <div className={result}>
      <h3>{date}</h3>
      <p>Min Temp: {item.main.temp_min}</p>
      <p>Max Temp: {item.main.temp_max}</p>
      <div>
        Current weather is:
        <ul>
          {weather.map((item, index) =>
            <li key={index}>{item.main} - {item.description}</li>
          )}
        </ul>
      </div>
    </div>
  )
}

export default ResultCard;
