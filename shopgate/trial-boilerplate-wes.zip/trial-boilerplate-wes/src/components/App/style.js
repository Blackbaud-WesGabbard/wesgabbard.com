import { css } from 'glamor';

css.global('body, figure', {
  margin: 0,
  fontFamily: 'Arial, Helvetica, sans-serif'
});

css.global('h1, h2, h3', {
  color: '#D26C22'
});

css.global('img, svg', {
  display: 'block',
  maxWidth: '100%',
});

let container = css({
  mxWidth: '500px',
  display: 'flex',
  justifyContent: 'center'
})
