import React from 'react';
import Container from '../Container';
import Form from '../Form';
import Logo from '../Logo';
import './style';

/**
 * @returns {JSX}
 */
const App = () => (
  <div>
    <Logo />
    <Container>
      <h1>Local Weather Lookup</h1>
      <Form />
    </Container>
  </div>
);

export default App;
