import axios from 'axios'

const APPID = 'e552aaed44b7ed34cc618b6b92cbf62d'

export function getWeather(city, country) {
  const weather = axios.get(`https://samples.openweathermap.org/data/2.5/weather?q=${city},${country}&APPID=${APPID}`)

  return weather.data;
}

export function getForecast(city) {
  Promise.resolve()
    return axios.get(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&APPID=${APPID}&units=imperial`)
      .then((data) => {
        return data
      })
      .catch(error => {
        return Promise.reject(error)
      })
}
